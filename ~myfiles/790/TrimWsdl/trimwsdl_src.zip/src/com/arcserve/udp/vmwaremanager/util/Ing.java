package com.arcserve.udp.vmwaremanager.util;


/**
 * To print progress.
 */
public class Ing
{
	
	private Thread ingThread = null;
	private double totalSeconds = 0;
	
	public void start()
	{
		stop();
		ingThread = new Thread(new Runnable(){

			@Override
			public void run()
			{
				long start = System.currentTimeMillis();
				while (true)
				{
					try
					{
						Thread.sleep(500);
					}
					catch (InterruptedException e)
					{
						Ing.this.totalSeconds = ((double)System.currentTimeMillis()-start)/1000;
						break;
					}
					
					System.out.printf(".");
				}
			}});
		
		ingThread.setDaemon(true);
		ingThread.start();			
	}
	
	public void stop()
	{
		if (ingThread != null)
		{
			ingThread.interrupt();
			
			while(ingThread.isAlive())
			{
				try
				{
					Thread.sleep(100);
				}
				catch (InterruptedException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				
		}
	}		
	
	public String getTotalSecondsString()
	{
		return String.format("(%.3f Seconds)", totalSeconds);
	}
}
