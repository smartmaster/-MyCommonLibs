package com.arcserve.udp.vmwaremanager.wsdl;

import java.io.File;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;

import com.arcserve.udp.vmwaremanager.util.TestLog;

public class TrimWsdl
{
	private static Logger log = Logger.getLogger(TrimWsdl.class);
	
	public TrimWsdl()
	{
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args)
	{
		try
		{
			log.info("start");
			do
			{
				if (args.length < 3)
				{
					System.out.println("Usage: " + TrimWsdl.class.getSimpleName() + " <source wsdl file> <output folder> <whitelist json file>");
					System.out.println("Example: " + TrimWsdl.class.getSimpleName() + " E:\\vim_wsdl\\vim.wsdl E:\\wim_wsdl_mini E:\\vim_whitelist.json");
					break;
				}
				
				String sourceWsdlFile = args[0];
				String targetFolder =   args[1];
				String whiteListFile =  args[2];
				
				
				File file = new File(sourceWsdlFile);
				if (!(file.isFile() && file.exists()))
				{
					System.out.println("<source wsdl file>:" + sourceWsdlFile + " doesn't exist.");
					break;
				}
				
				file = new File(targetFolder);
				if (!file.isDirectory())
				{
					System.out.println("<output folder>: " + targetFolder + " is not a folder");
					break;
				}
				
				if (!file.exists())
				{
					System.out.println("creating " + targetFolder);
					file.mkdirs();
				}
				
				System.out.println("java.class.path=" + System.getProperty("java.class.path"));

				TestLog testLog = new TestLog(TrimWsdl.class.getSimpleName());
				testLog.initLog();
				
//				sourceWsdlFile = "E:\\softlib\\Programming\\gsoap_2.8.59\\gsoap-2.8\\gsoap\\bin\\win32\\vim_wsdl\\vim.wsdl";
//				targetFolder =   "E:\\softlib\\Programming\\gsoap_2.8.59\\gsoap-2.8\\gsoap\\bin\\win32\\mini\\vim_wsdl\\";
//				whiteListFile =  "E:\\softlib\\Programming\\gsoap_2.8.59\\gsoap-2.8\\gsoap\\bin\\win32\\vim_whitelist.json";
//				
//				trim(sourceWsdlFile, targetFolder, whiteListFile);
//				
//				sourceWsdlFile = "E:\\softlib\\Programming\\gsoap_2.8.59\\gsoap-2.8\\gsoap\\bin\\win32\\pbm_wsdl\\pbm.wsdl";
//				targetFolder =   "E:\\softlib\\Programming\\gsoap_2.8.59\\gsoap-2.8\\gsoap\\bin\\win32\\mini\\pbm_wsdl\\";
//				whiteListFile =  "E:\\softlib\\Programming\\gsoap_2.8.59\\gsoap-2.8\\gsoap\\bin\\win32\\pbm_whitelist.json";
				
				trim(sourceWsdlFile, targetFolder, whiteListFile);
				
			}
			while (false);
			
			
			log.info("end");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void trim(String sourceWsdlFile, String targetFolder, String whiteListFile) throws Exception
	{
		ObjectMapper objectMapper = new ObjectMapper();
		WsdlWhiteList whiteList = objectMapper.readValue(new File(whiteListFile), WsdlWhiteList.class);
		
		WsdlTrimmer trimmer = new WsdlTrimmer(sourceWsdlFile, targetFolder, whiteList);		
		trimmer.run();
	}
	
	private void old_code()
	{
//		List<String> list = new ArrayList<String>();
		
		// vim25
		
		// login
//		list.add("RetrieveServiceContent");
//		list.add("Login");
//		list.add("Logout");
//
//		// iofilter
//		list.add("InstallIoFilter_Task");
//		list.add("QueryDisksUsingFilter");
//		list.add("QueryIoFilterInfo");
//		list.add("QueryIoFilterIssues");
//		list.add("ResolveInstallationErrorsOnCluster_Task");
//		list.add("ResolveInstallationErrorsOnHost_Task");		
//		list.add("UninstallIoFilter_Task");		
//		list.add("UpgradeIoFilter_Task");
		
		
		// pbm
//		list.add("PbmRetrieveServiceContent");
//		
//		// PbmProfileProfileManager
//		list.add("PbmCreate");
//		list.add("PbmDelete");
//		list.add("PbmFetchCapabilityMetadata");
//		list.add("PbmFetchCapabilitySchema");
//		list.add("PbmFetchResourceType");
//		list.add("PbmFetchVendorInfo");
//		list.add("PbmQueryAssociatedEntity");
//		list.add("PbmQueryAssociatedProfile");
		
//		objectMapper.writeValue(new File("pbm_white_list.json"), whiteList);
		
	}

}
