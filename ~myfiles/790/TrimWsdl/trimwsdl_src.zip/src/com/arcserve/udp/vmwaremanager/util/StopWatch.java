package com.arcserve.udp.vmwaremanager.util;

import java.util.Date;

public class StopWatch
{
	private long start = 0;
	private long last = 0;
	
	public StopWatch()
	{
		System.out.print("[>>: " + new Date() + "]\n");
	}
	
	public void start()
	{
		start = System.currentTimeMillis();			
		last = 0;
	}
	
	public void pause()
	{
		long previous = last == 0 ? start : last;
		long current = System.currentTimeMillis();
		System.out.printf("[||: %.3f Seconds]\n", ((double)current-previous)/1000);
		last = current;
	}
	
	public void stop()
	{
		System.out.printf("[<<: Total %.3f Seconds]\n", ((double)System.currentTimeMillis()-start)/1000);
	}	
}
