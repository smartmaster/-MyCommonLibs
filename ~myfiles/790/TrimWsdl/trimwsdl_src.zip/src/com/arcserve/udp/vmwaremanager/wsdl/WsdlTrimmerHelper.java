package com.arcserve.udp.vmwaremanager.wsdl;

public class WsdlTrimmerHelper
{
	public static void print(String format, Object ... args)
	{
		System.out.printf(format + "\n", args);
	}
	
	public static String getShortName(String name)
	{
		String result = name;
		
		if (name != null && !name.isEmpty())
		{
			int pos = name.indexOf(":");
			if (pos >= 0)
			{
				result = name.substring(pos + 1);
			}
		}	
		
		return result;
	}
	
	public static String getFileName(String fullPath)
	{
		String result = fullPath;
		
		if (fullPath != null && !fullPath.isEmpty())
		{
			int pos = fullPath.lastIndexOf("\\");
			if (pos == -1)
			{
				pos = fullPath.lastIndexOf("/");
			}
			
			if (pos >= 0)
			{
				result = fullPath.substring(pos + 1);
			}
		}
		
		return result;
	}
	
	public static String getFileFolder(String fullPath)
	{
		String result = fullPath;
		
		if (fullPath != null && !fullPath.isEmpty())
		{
			int pos = fullPath.lastIndexOf("\\");
			if (pos == -1)
			{
				pos = fullPath.lastIndexOf("/");
			}
			
			if (pos >= 0)
			{
				result = fullPath.substring(0, pos + 1);
			}
		}
		
		return result;
	}
	
}
