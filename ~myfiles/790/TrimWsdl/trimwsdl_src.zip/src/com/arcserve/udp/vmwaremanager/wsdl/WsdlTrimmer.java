package com.arcserve.udp.vmwaremanager.wsdl;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.arcserve.udp.vmwaremanager.util.Ing;
import com.arcserve.udp.vmwaremanager.util.StopWatch;

public class WsdlTrimmer
{
	private static Logger log = Logger.getLogger(WsdlTrimmer.class);
	
	private Map<String, String> _operations = new HashMap<String, String>(); // reserved operations
	private Map<String, String> _messages = new HashMap<String, String>();	 // referred messages 	
	private Map<String, String> _elements = new HashMap<String, String>();   // referred elements
	private Map<String, String> _types = new HashMap<String, String>();      // referred types and reserved types
	
	
	private Map<String, Document> _xsdDocuments = new HashMap<String, Document>();
	private Map<String, Map<String, String>> _typeRelationships = new HashMap<String, Map<String, String>>();
	
	private Map<String, String> _allReferredTypes = new HashMap<String, String>();      // all referred types recursively
	
	
	String sourceFolder = null; // "d:\\vim_wsdl\\";
	String targetFolder = null; // "d:\\mini\\vim_wsdl\\";
	String wsdlFile = null; // "vim.wsdl";
	
	WsdlWhiteList whiteList = null;
	
	
	public WsdlTrimmer(String sourceWsdlFile, String targetFolder, WsdlWhiteList whiteList)
	{
		this.sourceFolder = WsdlTrimmerHelper.getFileFolder(sourceWsdlFile);
		this.wsdlFile = WsdlTrimmerHelper.getFileName(sourceWsdlFile);
		
		if (!targetFolder.endsWith("\\"))
		{
			targetFolder += "\\";
		}
		this.targetFolder = targetFolder;
		
		
		this.whiteList = whiteList;		
		for (String item : whiteList.getOperations())
		{
			_operations.put(item, item);			
		}
		
		for (String item : whiteList.getTypes())
		{
			_types.put(item, item);			
		}
	}	
	
	public void run() throws Exception
	{
		String sourceFile = sourceFolder + wsdlFile;
		String targetFile = targetFolder + wsdlFile;
		
		log.info("start " + wsdlFile);

		// --- start
		Ing ing = new Ing();		
		WsdlTrimmerHelper.print("\nLoading wsdl %s .", sourceFile);		
		ing.start();
		
		// --- load wsdl
		Document document = loadXml(sourceFile);
		
		ing.stop();
		WsdlTrimmerHelper.print("\nLoaded " + ing.getTotalSecondsString() + "\n");		
		
		WsdlTrimmerHelper.print("reserved operations = %d", _operations.size());
		WsdlTrimmerHelper.print("reserved types = %d", _types.size());
		
		// --- trim operations
		WsdlTrimmerHelper.print("\nTrimming start\n");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();	
		
		WsdlTrimmerHelper.print("\ntrimming operations in binding");
		trimOperationsInBinding(document, _operations);		
		stopWatch.pause();
		
		
		WsdlTrimmerHelper.print("\ntrimming operations in portType");
		_messages.putAll(trimOperationsInPortType(document, _operations));		
		WsdlTrimmerHelper.print("reserved messages = %d", _messages.size());
		stopWatch.pause();		
		
		// --- trim messages
		WsdlTrimmerHelper.print("\ntrimming messages");
		_elements.putAll(trimMessages(document, _messages));
		WsdlTrimmerHelper.print("reserved elements = %d", _elements.size());
		stopWatch.pause();	
		
		// --- trim elements
		WsdlTrimmerHelper.print("\ntrimming elements");
		_types.putAll(trimElements(document, _elements));
		WsdlTrimmerHelper.print("reserved types = %d (not including child types)", _types.size());
		stopWatch.pause();		
		
		// --- prepare types
		WsdlTrimmerHelper.print("\nloading xsd files");
		loadXsdDocuments(document, _xsdDocuments);		
		WsdlTrimmerHelper.print("loaded xsd files = %d", _xsdDocuments.size());
		stopWatch.pause();
		
		WsdlTrimmerHelper.print("\nloading type relationships");
		_typeRelationships.putAll(loadTypesRelationships(_xsdDocuments));
		WsdlTrimmerHelper.print("loaded types = %d", _typeRelationships.size());
		stopWatch.pause();			
		
		WsdlTrimmerHelper.print("\ngetting all referred types");		
		getAllReferredTypes(_types, _typeRelationships, _allReferredTypes);
		WsdlTrimmerHelper.print("all referred types = %d", _allReferredTypes.size());
		stopWatch.pause();
		
		// --- trim types
		WsdlTrimmerHelper.print("\ntrimming types");
		trimTypes(_xsdDocuments, _allReferredTypes);
		stopWatch.pause();			
		
		// --- save		
		WsdlTrimmerHelper.print("\nsaving");	
		saveXml(document, targetFile);
		WsdlTrimmerHelper.print("%s saved", targetFile);
		
		for (Entry<String, Document> entry : _xsdDocuments.entrySet())
		{
			String target = targetFolder + entry.getKey();
			saveXml(entry.getValue(), target);
			WsdlTrimmerHelper.print("%s saved", target);
		}	
		
		// --- done
		stopWatch.stop();
		
		log.info("end " + wsdlFile);
	}
	
	private Document loadXml(String path) throws Exception
	{
		File file = new File(path);		
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(file);
		
		return doc;
	}
	
	private void saveXml(Document document, String path) throws Exception
	{
		File file = new File(path);
		
		TransformerFactory tFactory = TransformerFactory.newInstance();
		Transformer transformer = tFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		DOMSource source = new DOMSource(document);
		StreamResult result = new StreamResult(file);
		transformer.transform(source, result);	
	}
	
	// remove element and its front text node
	private void removeElement(Element element)
	{
		if (element != null)
		{
			Node preTextNode = element.getPreviousSibling();
			if (preTextNode != null && preTextNode.getNodeType() == Node.TEXT_NODE)
			{
				element.getParentNode().removeChild(preTextNode);
			}
			element.getParentNode().removeChild(element);
		}
	}
	
	private void trimOperationsInBinding(Document document, Map<String, String> operations)
	{
		// get binding elements
		NodeList bindingList = document.getElementsByTagName("binding");
		
		WsdlTrimmerHelper.print("\t bindings count = %d", bindingList.getLength());
		
		for (int i = 0; i< bindingList.getLength() ; i++)
		{
			// a binding element
			Element binding = (Element) bindingList.item(i);
			
			WsdlTrimmerHelper.print("\t binding name = %s", binding.getAttribute("name"));
			
			// get operation elements
			NodeList operationList = binding.getElementsByTagName("operation");
			int totalCount = operationList.getLength();
			
			int removed = 0;
			
			for (int j = operationList.getLength() - 1 ; j >= 0 ; j--)
			{
				// a operation element
				Element operation = (Element) operationList.item(j);
				
				// operation name
				String operationName = operation.getAttribute("name");
				if (!operations.containsKey(operationName))
				{
					removeElement(operation);
					removed ++;
				}			
			}
			
			WsdlTrimmerHelper.print("\t operations removed = %d/%d", removed, totalCount);
		}
	}
	
	private Map<String, String> trimOperationsInPortType(Document document, Map<String, String> operations)
	{
		Map<String, String> result = new HashMap<String, String>();
		
		// get portType elements
		NodeList portTypeList = document.getElementsByTagName("portType");
		
		WsdlTrimmerHelper.print("\t portType count = %d", portTypeList.getLength());		
		for (int i = 0; i< portTypeList.getLength() ; i++)
		{
			// a portType element
			Element portType = (Element) portTypeList.item(i);
						
			WsdlTrimmerHelper.print("\t portType name = %s", portType.getAttribute("name"));
			
			NodeList operationList = portType.getElementsByTagName("operation");
			int totalCount = operationList.getLength();
			
			int removed = 0;
			
			for (int j = operationList.getLength() - 1 ; j >= 0 ; j--)
			{
				// a operation element
				Element operation = (Element) operationList.item(j);
				
				// operation name
				String operationName = operation.getAttribute("name");
				
				if (!operations.containsKey(operationName))
				{
					removeElement(operation);
					removed ++;
				}
				else 
				{
					NodeList childNodes = operation.getChildNodes();
					
					if (childNodes != null && childNodes.getLength() > 0)
					{
						for (int h = 0; h < childNodes.getLength(); h++)
						{
							if ( childNodes.item(h).getNodeType() != Node.ELEMENT_NODE)
							{
								continue;
							}
							
							Element child = (Element) childNodes.item(h);
							
							String message = WsdlTrimmerHelper.getShortName(child.getAttribute("message"));						
							if (message != null && !message.isEmpty())
							{
								result.put(message, message);
							}							
						}						
					}					
				}
			}
			
			WsdlTrimmerHelper.print("\t operations removed = %d/%d", removed, totalCount);
		}
		
		return result;
	}
	
	private Map<String, String> trimMessages(Document document, Map<String, String> messages)
	{
		Map<String, String> result = new HashMap<String, String>();
		
		// get message elements
		NodeList messageList = document.getElementsByTagName("message");
		
		int totalCount = messageList.getLength();
		
		int removed = 0;
		for (int i = messageList.getLength() - 1; i >= 0 ; i--)
		{
			// a message element
			Element message = (Element) messageList.item(i);
			
			// message name
			String messageName = message.getAttribute("name");
			
			if (!messages.containsKey(messageName))
			{
				removeElement(message);
				removed ++;
			}
			else 
			{
				NodeList partList = message.getElementsByTagName("part");
				
				if (partList != null && partList.getLength() > 0)
				{
					for (int j = 0; j < partList.getLength(); j++)
					{
						Element part = (Element) partList.item(j);
						
						String element = WsdlTrimmerHelper.getShortName(part.getAttribute("element"));						
						if (element != null && !element.isEmpty())
						{
							result.put(element, element);
						}		
					}						
				}					
			}
		}
		
		WsdlTrimmerHelper.print("\t messages removed = %d/%d", removed, totalCount);
		return result;
	}
	
	private Map<String, String> trimElements(Document document, Map<String, String> elements)
	{
		Map<String, String> result = new HashMap<String, String>();
		
		NodeList schemasList = document.getElementsByTagName("schema");
		
		int elementCount = 0;
		int removed = 0;		
		for (int i = 0; i < schemasList.getLength(); i++)
		{
			Element schema = (Element) schemasList.item(i);
			
			NodeList childList = schema.getChildNodes();			
			for (int j = childList.getLength() - 1 ; j >= 0 ; j--)
			{
				Node node = childList.item(j);
				
				if (node.getNodeType() != Node.ELEMENT_NODE || node.getNodeName() != "element")
				{
					continue;
				}
				
				elementCount++;
				
				Element element = (Element) node;				
				
				String elementName = element.getAttribute("name");
				
				if (!elements.containsKey(elementName))
				{
					removeElement(element);
					removed ++;
				}
				else 
				{
					String type = WsdlTrimmerHelper.getShortName(element.getAttribute("type"));
					if (type != null && !type.isEmpty())
					{
						result.put(type, type);
					}
					else 
					{
						NodeList childElementList = element.getElementsByTagName("element");
						
						if (childElementList != null && childElementList.getLength() > 0)
						{
							for (int k = 0; k < childElementList.getLength(); k++)
							{
								Element childElement = (Element) childElementList.item(k);
								
								if (childElement != null)
								{
									String childElementType = WsdlTrimmerHelper.getShortName(childElement.getAttribute("type"));									
									if (childElementType != null && !childElementType.isEmpty())
									{
										result.put(childElementType, childElementType);
									}		
								}
							}						
						}			
					}
				}
			}
		}
		
		
		WsdlTrimmerHelper.print("\t elements removed = %d/%d", removed, elementCount);
		return result;
	}
	
	private void loadXsdDocuments(Document document, Map<String, Document> xsdDocMap) throws Exception
	{
		NodeList schemasList = document.getElementsByTagName("schema");
		
		
		Map<String, String> subFiles = new HashMap<String, String>();
		
		for (int i = 0; i < schemasList.getLength(); i++)
		{
			Element schema = (Element) schemasList.item(i);
			
			NodeList importList = schema.getElementsByTagName("import");			
			for (int j = 0; j < importList.getLength(); j++)
			{
				Element element = (Element) importList.item(j);
				String xsd = element.getAttribute("schemaLocation");
				
				subFiles.put(xsd, xsd);								
			}
			
			NodeList includeList = schema.getElementsByTagName("include");			
			for (int j = 0; j < includeList.getLength(); j++)
			{
				Element element = (Element) includeList.item(j);
				String xsd = element.getAttribute("schemaLocation");
				subFiles.put(xsd, xsd);		
			}	
		}
		
		for (String xsd : subFiles.keySet())
		{
			if (!xsdDocMap.containsKey(xsd))
			{
				Document subDocument = loadXml(sourceFolder + xsd);
				xsdDocMap.put(xsd, subDocument);					
				loadXsdDocuments(subDocument, xsdDocMap);
			}
		}
	}
	
	private Map<String, Map<String, String>> loadTypesRelationships(Map<String, Document> xsdDocMap)
	{
		Map<String, Map<String, String>> result = new HashMap<String, Map<String, String>>();
		
		for (Document document : xsdDocMap.values())
		{
			result.putAll(loadTypesRelationships(document));
		}
		
		return result;		
	}
	
	private Map<String, Map<String, String>> loadTypesRelationships(Document document)
	{
		Map<String, Map<String, String>> result = new HashMap<String, Map<String, String>>();
		
		// simple type
		NodeList elementsList = document.getElementsByTagName("simpleType");
		for (int i = 0; i < elementsList.getLength() ; i++)
		{
			Element element =  (Element) elementsList.item(i);
			String value = WsdlTrimmerHelper.getShortName(element.getAttribute("name"));						
			if (value != null && !value.isEmpty())
			{
				result.put(value, null);
			}		
		}
		
		// complex type
		elementsList = document.getElementsByTagName("complexType");
		for (int i = 0; i < elementsList.getLength() ; i++)
		{
			Element element =  (Element) elementsList.item(i);
			String name = WsdlTrimmerHelper.getShortName(element.getAttribute("name"));
			
			Map<String, String> map = new HashMap<String, String>();
			
			// extension
			NodeList childElementList  = element.getElementsByTagName("extension");
			for (int j = 0; j<childElementList.getLength(); j++)
			{
				Element childElement =  (Element) childElementList.item(j);
				String value = WsdlTrimmerHelper.getShortName(childElement.getAttribute("base"));						
				if (value != null && !value.isEmpty())
				{
					map.put(value, value);
				}
			}
			
			// elements
			childElementList  = element.getElementsByTagName("element");
			for (int j = 0; j<childElementList.getLength(); j++)
			{
				Element childElement =  (Element) childElementList.item(j);
				String value = WsdlTrimmerHelper.getShortName(childElement.getAttribute("type"));						
				if (value != null && !value.isEmpty())
				{
					map.put(value, value);
				}
			}
			
			result.put(name, map);			
		}	
		
		WsdlTrimmerHelper.print("\t %d types in %s", result.size(), WsdlTrimmerHelper.getFileName(document.getDocumentURI()));
		
		return result;		
	}
	
	
	private void getAllReferredTypes(Map<String, String> types, Map<String, Map<String, String>> typeRelationships, Map<String, String> allTypes)
	{
		for (String type : types.keySet())
		{
			if (!allTypes.containsKey(type))
			{
				allTypes.put(type, type);
				//WsdlTrimmerHelper.print("\t type = %s", type);
				
				Map<String, String> childTypes = typeRelationships.get(type);
				if (childTypes != null && !childTypes.isEmpty())
				{
					getAllReferredTypes(childTypes, typeRelationships, allTypes);
				}	
			}
		}		
	}
	
	private void trimTypes(Map<String, Document> xsdDocMap, Map<String, String> types)
	{
		for (Document document : xsdDocMap.values())
		{
			trimTypes(document, types);		
		}
	}
	
	
	
	private void trimTypes(Document document, Map<String, String> types)
	{
		int removed = 0;
		int total = 0;
		
		// simple type
		NodeList elementsList = document.getElementsByTagName("simpleType");
		total += elementsList.getLength();
		for (int i = elementsList.getLength() - 1; i >= 0 ; i--)
		{
			Element element =  (Element) elementsList.item(i);
			String value = WsdlTrimmerHelper.getShortName(element.getAttribute("name"));
			
			if (!types.containsKey(value))
			{
				removeElement(element);
				removed++;
			}
		}
		
		// complex type
		elementsList = document.getElementsByTagName("complexType");
		total += elementsList.getLength();
		for (int i = elementsList.getLength() - 1; i >= 0 ; i--)
		{
			Element element =  (Element) elementsList.item(i);
			String value = WsdlTrimmerHelper.getShortName(element.getAttribute("name"));
			
			if (!types.containsKey(value))
			{
				removeElement(element);
				removed++;
			}			
		}	
		
		WsdlTrimmerHelper.print("\t types removed = %d/%d in %s", removed, total, WsdlTrimmerHelper.getFileName(document.getDocumentURI()));
	}
}
