package com.arcserve.udp.vmwaremanager.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TestLog
{
	private static Logger log = Logger.getLogger(TestLog.class);
	private String logName;
	public TestLog(String logName)
	{
		this.logName = logName;
		log.debug("from testLog");
	}
	
	public void initLog() throws IOException
	{			
		String log4jFile = "log4j-TestLog.properties";
		InputStream input = TestLog.class.getResourceAsStream(log4jFile);
		java.util.Properties props = new java.util.Properties();
		props.load(input);
		{
			if (input != null)
			{
				LogUtils.updatePid();
				props.load(input);
				//String temp = props.getProperty("log4j.appender.logout.File");
				//props.setProperty("log4j.appender.logout.File", temp.replace("TestLog", logName));
				props.setProperty("log4j.appender.logout.File", "./" + logName + ".log");
				PropertyConfigurator.configure(props);
			}

			// print out the log file full path
			String temp = props.getProperty("log4j.appender.logout.File");
			System.out.println("Log file: " + new File(temp).getCanonicalPath());
		}
	}
	
	public void testAppender()
	{
		Logger log = Logger.getLogger(
				com.arcserve.udp.vmwaremanager.TestVMWareManager.class);
		
		log.debug("before add");
		
		LogUtils.addAppender();
		
		log.debug("after add");
		
		log.debug("before remove");
		
		LogUtils.removeAppender();
		
		log.debug("after remove");		
		
		logSomeLogs();
	}
	
	public void logSomeLogs()
	{
		log.debug("from logSomeLogs");
	}
	
	/**
	 * Inits the log.
	 *
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	protected void initLog_VMwareManager() throws IOException
	{			
		String log4jFile = "log4j-VMwareManager.properties";
		InputStream input = this.getClass().getResourceAsStream(log4jFile);
		java.util.Properties props = new java.util.Properties();
		props.load(input);
		{
			if (input != null)
			{
				LogUtils.updatePid();
				props.load(input);
				PropertyConfigurator.configure(props);
			}

			// print out the log file full path
			String temp = props.getProperty("log4j.appender.logout.File");
			System.out.println("Log file: " + new File(temp).getCanonicalPath());
		}
	}	

}
