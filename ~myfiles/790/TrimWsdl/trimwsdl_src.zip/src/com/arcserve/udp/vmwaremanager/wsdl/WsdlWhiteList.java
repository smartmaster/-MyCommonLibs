package com.arcserve.udp.vmwaremanager.wsdl;

import java.util.ArrayList;
import java.util.List;

public class WsdlWhiteList
{	
	// reserved operations, could be a name of a operation tag. 
	// all the relevant types will be reserved automatically
	private List<String> operations = new ArrayList<String>(); 
	
	// reserved types, could be the name of a simpleType tag or a complexType tag.
	// use this when you want to reserve a type which is not referred by any of the above operations
	private List<String> types = new ArrayList<String>();

	public List<String> getOperations()
	{
		return operations;
	}

	public void setOperations(List<String> operations)
	{
		this.operations = operations;
	}

	public List<String> getTypes()
	{
		return types;
	}

	public void setTypes(List<String> types)
	{
		this.types = types;
	} 	
}
