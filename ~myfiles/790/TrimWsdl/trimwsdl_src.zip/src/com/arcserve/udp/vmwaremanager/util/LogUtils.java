package com.arcserve.udp.vmwaremanager.util;

import java.lang.management.ManagementFactory;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.apache.log4j.RollingFileAppender;

public class LogUtils
{
	private static final String LOGGER_NAME = "com.ca.arcflash.ha.vmwaremanager";
	private static final String APPENDER_NAME = "logout";
	private static final String APPENDER_NAME_NEW = "logout2";
	private static final String FILE_TOKEN = ".log";
	
	private static Logger logHere = Logger.getLogger(LogUtils.class);
	
	private static String getPid()
	{
		String name = ManagementFactory.getRuntimeMXBean().getName();  
		String pid = name.split("@")[0];
		return pid; 		
	}
	
	// add an appender to output logs to the VMwareManager_pid.err e.g. VMwareManager_23528.err
	public static void addAppender()
	{
		try
		{
			String pid = getPid();
			
			MDC.put("PID", pid); // to output pid in logs
			
			// get the current appender
			Logger log = Logger.getLogger(LOGGER_NAME);
			RollingFileAppender appender = (RollingFileAppender) log.getAppender(APPENDER_NAME);	
			
			
			// create a new appender
			RollingFileAppender newAppender = new RollingFileAppender();
			newAppender.setName(APPENDER_NAME_NEW);
			newAppender.setMaximumFileSize(appender.getMaximumFileSize());
			newAppender.setMaxBackupIndex(appender.getMaxBackupIndex());
			newAppender.setAppend(false);
			newAppender.setLayout(appender.getLayout());
			
			// change the file name
			String file = appender.getFile();
			String newFile = file.replace(FILE_TOKEN, "_" + pid + ".err");
			newAppender.setFile(newFile);
						
			newAppender.activateOptions();
			
			// append it to the root logger
			Logger root = Logger.getRootLogger();
			root.addAppender(newAppender);
		}
		catch(Exception e)
		{
			logHere.error("Failed to add appender", e);
		}
	}
	
	// remove the appender
	public static void removeAppender()
	{		
		try
		{
			Logger root = Logger.getRootLogger();
			root.removeAppender(APPENDER_NAME_NEW);
		}
		catch (Exception e)
		{
			logHere.error("Failed to remove appender", e);
		}
	}
	
	public static void updatePid()
	{
		try
		{
			String pid = getPid();
			MDC.put("PID", pid); // to output pid in logs
		}
		catch (Exception e)
		{
			logHere.error("Failed to update pid", e);
		}
	}
}
